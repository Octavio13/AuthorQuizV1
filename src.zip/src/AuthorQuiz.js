import React, { useState } from 'react';
import './App.css';
import './bootstrap.min.css';
import { Book } from './Book';
import {Hero} from './Hero';
import {Turn} from './Turn';


// // Hero is the nam of the first component?
// function Hero() {
//   return (
//     <div className="row">
//       <div className="jumbotron col-10 offset-1">
//         <h1>AuthorQuiz</h1>
//         <p>Select the book written by the author shown</p>
//       </div>
//     </div>);
// }

// //Turn is another component
// function Turn({ author, books, authors }) {
//   const [isCorrect, setIsCorrect] = useState(books);
//   const [SelectedTitle, setSelectedTitle] = useState(books);

//   const onSelection = (x) => {
//     setSelectedTitle(x)
//     // console.log(author)
//     // console.log(x)
//     // console.log(authors)
//     // debugger
//     const selectedAuthor = authors.find(x => x.name = author.name)
//     setIsCorrect(selectedAuthor.books.includes(x))
//     console.log(selectedAuthor.books)

//   }
//   return (

//     <div className="row turn" style={{ backgroundColor: "white" }}>
//       <div className="col-4 offset-1">
//         {author.name}
//         <img src={author.imageUrl} className="authorimage" />
//       </div>

//       <div className="col-6">
//         {books.map((title, index) => <Book title={title} onSelection={onSelection} 
//         isCorrect={SelectedTitle === title && isCorrect === true} isWrong={SelectedTitle === title && isCorrect === false} key={index}></Book>)}
//       </div>
//     </div>

//   );
// }

//This is the third component
function Continue() {
  return (
    <div></div>
  );
}

//This is the fourth component

// function Footer() {
//   return (<div id="footer" className="row">
//     <div className="col-12">
//       <p className="text-muted credit">All imaes are from <a>href="http://commons.wikipedia.org/wiki/Media"</a></p>
//     </div>
//     <div />);

export function Footer() {
  return (
    <div id="footer" className="row">
      <div className="col-12">
        <p className="text-muted credit">All images are from <a href="https://commons.wikimedia.org/wiki/Main_Page"></a></p>
      </div>
    </div>
  );
}

//Below is the main part of the code which calls
//the components listed above

export function AuthorQuiz({ turnData, authors }) {
  return (
    <div className="container-fluid">
      <Hero />
      <Turn {...turnData} authors={authors} />
      <Continue />
      <Footer />
    </div>
  );
}


// export default AuthorQuiz;