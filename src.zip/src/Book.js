import React from 'react';
// tittle is an argument
export const Book = ({ title, onSelection, isCorrect, isWrong }) => {
    return (<div className="answer" style={{ background: isCorrect ? 'green' : isWrong ? 'red' : '' }}>
        <h4 style={{ cursor: 'pointer' }} onClick={(x) => onSelection(title)}> {title} </h4>
    </div>);
}

