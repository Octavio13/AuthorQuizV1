import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { AuthorQuiz } from './AuthorQuiz';
import * as serviceWorker from './serviceWorker';

const authors = [
    {
        name: 'Mark Twain',
        imageUrl: 'images/authors/marktwain.jpg',
        imageSource: 'Wikimedia Commons',
        books: ['The adventures of huknleberry Finn']
    },

    {
        name: 'Joseph Conrad',
        imageUrl: 'images/authors/JosephConrad.png',
        imageSource: 'Wikimedia Commons',
        books: ['Heart of Darkness']
    },

    {
        name: 'JK Rowlin',
        imageUrl: 'images/authors/jkrowling.jpg',
        imageSource: 'Wikimedia Commons',
        imageAttribution: 'Daniel Ogren',
        books: ['Harry Potter and the Sorcerer Stone']
    },

    {
        name: 'Stephen King',
        imageUrl: 'images/authors/stephenking.jpg',
        imageAttribution: 'Pinguino',
        imageSource: 'Wikimedia Commons',
        books: ['The Shining', 'IT']
    },

    {
        name: 'Charles Dickens',
        imageUrl: 'images/authors/charlesdickens.jpg',
        imageSource: 'Wikimedia Commons',
        books: ['David Coperfield', 'A tale of two cities']
    },

    {
        name: 'William Shakespare',
        imageUrl: 'images/authors/williamshakespare.jpg',
        imageSource: 'Wikimedia Commons',
        books: ['Hamlet', 'Mcbeth', 'Romeo and Juliet']
    },

];

const state = {
    turnData: getTurnData(authors),
    authors
};

function getRandom(top) {
    return Math.floor(Math.random() * top)
}

//this needs completion
function getTurnData(authors) {

    // const allBooks = authors.reduce(function (p, c, i) {
    //     return p.concat(c.books);
    // })
    // const allBooks = authors.reduce(i
    //     return [];
    const booksData = authors.reduce((a, c) => {
        return a = [...a, ...c.books]
    }, [])

    const data = authors.map(a => {
        return { name: a.name, imageUrl: a.imageUrl };
    })

    let books = [];
    while (books.length < 4) {
        const newRandomBook = booksData[getRandom(booksData.length - 1)]       
        books = [...books.filter(x => x !== newRandomBook), newRandomBook]
    }
    console.log(books)
    return { author: data[getRandom(data.length - 1)], books };
}



ReactDOM.render(<AuthorQuiz {...state} />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
