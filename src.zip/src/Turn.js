import React, { useState } from 'react';
import { Book } from './Book';

//Turn is another component
export function Turn({ author, books, authors }) {
    const [isCorrect, setIsCorrect] = useState(books);
    const [SelectedTitle, setSelectedTitle] = useState(books);
  
    const onSelection = (x) => {
      setSelectedTitle(x)
      // console.log(author)
      // console.log(x)
      // console.log(authors)
      // debugger
      const selectedAuthor = authors.find(x => x.name = author.name)
      setIsCorrect(selectedAuthor.books.includes(x))
      console.log(selectedAuthor.books)
  
    }
    return (
  
      <div className="row turn" style={{ backgroundColor: "white" }}>
        <div className="col-4 offset-1">
          {author.name}
          <img src={author.imageUrl} className="authorimage" />
        </div>
  
        <div className="col-6">
          {books.map((title, index) => <Book title={title} onSelection={onSelection} 
          isCorrect={SelectedTitle === title && isCorrect === true} isWrong={SelectedTitle === title && isCorrect === false} key={index}></Book>)}
        </div>
      </div>
  
    );
  }
